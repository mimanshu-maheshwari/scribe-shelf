package com.infy.resolver;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.graphql.data.method.annotation.SchemaMapping;

import org.springframework.stereotype.Controller;


import com.infy.service.Services;



@Controller
public class QueryResolver {

	@Autowired
	private Services service;
	
	@SchemaMapping(typeName="Query",field="message")
	public String getMessage()
	{
		return service.getMessage();
	}
}
