package com.infy.service;

import org.springframework.stereotype.Service;



@Service
public class Services {

	
	 static final String MESSAGE = "Welcome to GraphQL Annotations Practice Session";
	
	public String getMessage()
	{
		return MESSAGE;
	}
}
