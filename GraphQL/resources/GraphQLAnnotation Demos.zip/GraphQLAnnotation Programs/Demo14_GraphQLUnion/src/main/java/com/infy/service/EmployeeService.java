package com.infy.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.entity.Employee;
import com.infy.repository.EmployeeRepository;

import java.util.List;
import java.util.Optional;
 
@Service
public class EmployeeService {
	@Autowired
    private EmployeeRepository employeeRepository ;
	
	public Employee getEmployeeById(String employeeId)
	{
		Employee employee = null;
		Optional<Employee> employeeOptional = employeeRepository.findById(employeeId);
		if(employeeOptional.isPresent())
			employee = employeeOptional.get();
		return employee;
	}
	
    public List<Employee> getAllEmployees( ) {
        return this.employeeRepository.findAll();
    }
    
    public String getMessage(Employee emp)
    {
    	return emp.getFirstName()+" "+emp.getLastName();
    }
    public Employee createEmployee(Employee employee)
    {
    	return employeeRepository.saveAndFlush(employee);
    }
    
}
