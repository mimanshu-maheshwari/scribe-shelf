package com.infy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.repository.CompanyRepository;
import com.infy.repository.EmployeeRepository;

@Service
public class TECDetailsService 
{
	@Autowired
	EmployeeRepository employeeRepo;
	@Autowired
	CompanyRepository companyRepo;
	//Collective details of Company and Employee together
	public List<Object> getTecDetails()
	{
		List<Object> tecDetails = new ArrayList<>();
		List<Employee> employees = employeeRepo.findAll();
		for(Employee employee : employees)
		{
			tecDetails.add(employee);
		}
		List<Company> companies = companyRepo.findAll();
		for(Company company : companies)
		{
			tecDetails.add(company);
		}
		return tecDetails;
	}
}

