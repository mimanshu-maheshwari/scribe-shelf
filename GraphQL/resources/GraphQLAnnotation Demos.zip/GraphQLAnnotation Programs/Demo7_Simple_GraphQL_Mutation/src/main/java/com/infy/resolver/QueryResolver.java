package com.infy.resolver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import com.infy.service.MessageService;

@Controller
public class QueryResolver 
{
	@Autowired
	private MessageService messageservice;
	
	@SchemaMapping(typeName="Query",field="message")
	public String getMessage()
	{
		return messageservice.getMessage();
	}
}
