package com.infy.resolver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import com.infy.service.MessageService;

@Controller
public class MutationResolver{

	@Autowired
	private MessageService messageservice;

	@SchemaMapping(typeName="Mutation")
	public String addMessage(@Argument("name") String message) {
		messageservice.setMessage(message);
		return messageservice.getMessage();
	}
}