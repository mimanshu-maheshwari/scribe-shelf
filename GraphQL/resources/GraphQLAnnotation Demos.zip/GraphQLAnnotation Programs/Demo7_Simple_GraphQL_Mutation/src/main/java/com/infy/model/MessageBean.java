package com.infy.model;

import org.springframework.stereotype.Component;
@Component
public class MessageBean
{
	String message;
	public MessageBean()
	{ 
		this.message="Hello!";
	}
	public String getMessage()
	{
		return message;
	}
	public void setMessage(String message)
	{
		this.message = message;
	}
}

