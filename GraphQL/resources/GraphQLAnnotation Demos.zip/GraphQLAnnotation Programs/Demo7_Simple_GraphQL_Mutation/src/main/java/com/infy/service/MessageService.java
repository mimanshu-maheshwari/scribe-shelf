package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.model.MessageBean;

@Service
public class MessageService {
	@Autowired
	MessageBean messageBean;

	public MessageService() {
		super();
	}

	public String getMessage() {
		return messageBean.getMessage();
	}

	public void setMessage(String message) {
		this.messageBean.setMessage(message);
	}
}

