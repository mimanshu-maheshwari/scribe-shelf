package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.infy.entity.Employee;

import com.infy.repo.EmployeeRepository;


@Service
public class Services {

	@Autowired
	private EmployeeRepository empRepo;
	static final String MESSAGE = "Simple Employee Schema";
	public List<Employee> getEmployees()
	{
		return empRepo.findAll();
		
	}
	public String getMessage()
	{
		return MESSAGE;
	}
}
