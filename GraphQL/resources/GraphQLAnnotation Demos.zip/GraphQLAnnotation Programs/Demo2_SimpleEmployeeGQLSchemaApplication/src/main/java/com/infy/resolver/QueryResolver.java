package com.infy.resolver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;

import org.springframework.stereotype.Controller;

import com.infy.entity.Employee;

import com.infy.service.Services;



@Controller
public class QueryResolver {

	@Autowired
	private Services service;
	
	@SchemaMapping(typeName="Query")
	public List<Employee> employees()
	{
		
		return service.getEmployees();
	}
	//@SchemaMapping(typeName="Query",field="message")
	@QueryMapping
	public String message()
	{
		return service.getMessage();
	}
}
