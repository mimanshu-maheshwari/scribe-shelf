package com.infy.service;
import java.util.Optional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.exception.TECException;
import com.infy.repository.CompanyRepository;
import com.infy.repository.EmployeeRepository;
@Service
public class EmployeeCompanyMutationService {
	@Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
	private CompanyRepository companyRepository;
	
    private static final Log LOGGER = LogFactory.getLog(EmployeeCompanyMutationService.class); 
    
	public Company addCompany(Company tec) {
		Company comp=null;
	    try {
		  comp = companyRepository.saveAndFlush(tec);}
	    catch(Exception e) {LOGGER.error(e);}
		return comp;
	}
	public Employee addEmployee(Employee emp) {
		return employeeRepository.saveAndFlush(emp);
		
	}
	public Employee unmapCompEmp(String cid, String eid) {
		if (!this.employeeRepository.existsById(eid))
			throw new TECException("Invalid Employee");
		if (!this.companyRepository.existsById(cid))
			throw new TECException("Invalid Company");
		 
		Optional<Employee> employeeOptional = this.employeeRepository.findById(eid);
		if(employeeOptional.isPresent())
		{
			Employee emp = employeeOptional.get();
			if (this.companyRepository.existsById(cid)) 
			{
				emp.setCompany(null);
				return this.employeeRepository.saveAndFlush(emp);
			}
		}
		
		return null;
		
	}
	public Employee mapEmpComp(String cid, String eid) {
		if (!this.employeeRepository.existsById(eid))
			throw new TECException("Inavlid Employee");
		if (!this.companyRepository.existsById(cid))
			throw new TECException("Inavlid Company");
		
		Optional<Employee> employeeOptional = employeeRepository.findById(eid);
		if(employeeOptional.isPresent())
		{
			Optional<Company> companyOptional = companyRepository.findById(cid);
			if(companyOptional.isPresent())
			{
				Employee emp =employeeOptional.get(); 
				emp.setCompany(companyOptional.get());
				return this.employeeRepository.saveAndFlush(emp);
			}
		}
		return null;
		
	}
}
