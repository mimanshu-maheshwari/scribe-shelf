package com.infy.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.Company;

import com.infy.repo.CompanyRepository;




@Service
public class CompanyServices {

	@Autowired
	private CompanyRepository compRepo;
		
	public List<Company> getAllCompanies()
	{
		return compRepo.findAll();
	}
	public Company getCompanyById(String id)
	{
		Optional<Company> comp = compRepo.findById(id);
		if(comp.isPresent())
		{
			return comp.get();
		}
		return null;
	}
	
	public List<Company> getAllEmployees( ) {
	        return compRepo.findAll();
	    }
	    
}
