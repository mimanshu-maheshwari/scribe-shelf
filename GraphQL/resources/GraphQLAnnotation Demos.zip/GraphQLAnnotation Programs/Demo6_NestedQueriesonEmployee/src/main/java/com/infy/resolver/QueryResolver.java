package com.infy.resolver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;

import org.springframework.stereotype.Controller;

import com.infy.entity.Company;
import com.infy.entity.Employee;

import com.infy.service.CompanyServices;
import com.infy.service.EmployeeServices;



@Controller
public class QueryResolver {

	@Autowired
	private CompanyServices compService;
	
	@Autowired
	private EmployeeServices empService;
	
	@SchemaMapping(typeName="Query")
	public List<Employee> employees()
	{
		
		return empService.getEmployees();
	}
	@SchemaMapping(typeName="Query",field = "companies")
	public List<Company> getCompanies()
	{
		
		return compService.getAllCompanies();
		
	}
	
	@QueryMapping(name="employeeById")
	public Employee employeeById(@Argument("id") String id)
	{
		return empService.getEmployeeById(id);
	}
	@QueryMapping
	public Company companyById(@Argument("id") String id)
	{
		return compService.getCompanyById(id);
	}
	
	@SchemaMapping(typeName="Employee")
	public String fullName(Employee emp)
	{
		
		return empService.fullName(emp);
	}
	@SchemaMapping(typeName="Employee")
	public Double totalSal(Employee emp)
	{
		return empService.totalSal(emp);
	}
	
}
