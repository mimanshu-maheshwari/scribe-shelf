package com.infy.resolver;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.repo.EmployeeRepository;




@Controller
public class EmployeeResolver{

	
	@Autowired
	private EmployeeRepository empRepo;
	
	
	@SchemaMapping(typeName="Employee",field="company")
	public Company getCompany(Employee employee)
	{
		Optional<Employee> comp = empRepo.findById(employee.getId());
		Company com = null;
		if(comp.isPresent())
					return (comp.get()).getEmpcompany();
		return com;
	}
}
