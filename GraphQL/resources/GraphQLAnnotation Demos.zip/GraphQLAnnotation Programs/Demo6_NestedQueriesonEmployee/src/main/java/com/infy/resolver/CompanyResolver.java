package com.infy.resolver;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.repo.CompanyRepository;

//package and import statements
@Controller
public class CompanyResolver 
{
	@Autowired
	private CompanyRepository compRepo;
	
	@SchemaMapping(typeName="Company",field="employees")
	public List<Employee> compEmployees(Company company)
	{
		Optional<Company> comp = compRepo.findById(company.getcId());
		List<Employee> list = null;
		if(comp.isPresent())
			return comp.get().getCompemployees();
		return list;
	}
	
}

