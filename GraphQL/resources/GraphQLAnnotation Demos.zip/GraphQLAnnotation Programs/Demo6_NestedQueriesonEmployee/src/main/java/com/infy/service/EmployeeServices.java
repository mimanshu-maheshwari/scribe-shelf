package com.infy.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.infy.entity.Employee;

import com.infy.repo.EmployeeRepository;



@Service
public class EmployeeServices {

	@Autowired
	private EmployeeRepository empRepo;
	
	
	public List<Employee> getEmployees()
	{
		return empRepo.findAll();
		
	}
	
	public Employee getEmployeeById(String id) {
		Optional<Employee> emp = empRepo.findById(id);
		if(emp.isPresent())
		{
			return emp.get();
		}
		return null;
	}
	public String fullName(Employee emp) {
		return emp.getFirstName()+" "+emp.getLastName();
		}
	public Double totalSal(Employee emp) {
		Double hra = emp.getSalary()*0.05;
		Double ta = emp.getSalary()*0.13; 
		Double da = emp.getSalary()*0.2;
		// Assume da is 20%, ta is 13% and hra is 5% of basic 
		return emp.getSalary()+hra+ta+da;
	}
	
	
	
	
	
	    
}
