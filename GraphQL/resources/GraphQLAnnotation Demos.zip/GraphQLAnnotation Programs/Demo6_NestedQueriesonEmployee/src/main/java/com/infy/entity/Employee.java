package com.infy.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="employee2")
public class Employee {
	@Id
	 private String id;
	 private String firstName;
	 private String lastName;
	 private Integer jobLevel;
	 private Float salary;
	 
	 @ManyToOne(fetch = FetchType.EAGER)
		private Company empcompany;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getJobLevel() {
		return jobLevel;
	}

	public void setJobLevel(Integer jobLevel) {
		this.jobLevel = jobLevel;
	}

	public Float getSalary() {
		return salary;
	}

	public void setSalary(Float salary) {
		this.salary = salary;
	}

	public Company getEmpcompany() {
		return empcompany;
	}

	public void setEmpcompany(Company empcompany) {
		this.empcompany = empcompany;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", jobLevel=" + jobLevel
				+ ", salary=" + salary + ", empcompany=" + empcompany + "]";
	}

	public Employee(String id, String firstName, String lastName, Integer jobLevel, Float salary,
			Company empcompany) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.jobLevel = jobLevel;
		this.salary = salary;
		this.empcompany = empcompany;
	}

	public Employee() {
		super();
	}
	 
	 
	
	 
	 
}
