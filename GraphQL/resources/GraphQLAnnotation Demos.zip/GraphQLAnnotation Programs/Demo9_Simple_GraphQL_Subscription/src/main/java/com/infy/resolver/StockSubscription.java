package com.infy.resolver;

import reactor.core.publisher.Flux;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import java.time.Duration;
import java.util.Random;

@Controller
public class StockSubscription  {
	
	Random rand;
	public StockSubscription() {
	 rand = new Random();
	}

	@SchemaMapping(typeName="Subscription")
	public Flux<String> stockPrice(@Argument("company") String company) 
	{
		return Flux.interval(Duration.ofSeconds(10)).map(num -> 
			 "Stock value of  company : " + company + " is :" + rand.nextInt(5000));
	}
}
