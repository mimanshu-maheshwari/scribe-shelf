package com.infy.resolver;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import java.util.Random;

@Controller
public class StockQuery{
	
	Random rand;
	public StockQuery() {
		rand = new Random();
	}

	@SchemaMapping(typeName="Query")
	public String stockPrice(@Argument("company") String company) {
		
		return "Stock value of  company :" + company + ":" + rand.nextInt(5000);
	}
}
