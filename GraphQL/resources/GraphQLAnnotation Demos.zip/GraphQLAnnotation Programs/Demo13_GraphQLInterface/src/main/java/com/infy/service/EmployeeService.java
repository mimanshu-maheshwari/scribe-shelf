package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.ContractEmployee;
import com.infy.entity.Employee;
import com.infy.entity.PermanentEmployee;
import com.infy.repository.ContractEmployeeRepository;
import com.infy.repository.EmployeeRepository;
import com.infy.repository.PermanentEmployeeRepository;

//package and import statements
@Service
public class EmployeeService {
	@Autowired
    private EmployeeRepository employeeRepo;
	@Autowired
    private ContractEmployeeRepository contractEmployeeRepo;
	@Autowired
	private PermanentEmployeeRepository permanentEmployeeRepo;
	
	
	public List<PermanentEmployee> getPermanentEmployees()
	{
		return permanentEmployeeRepo.findAll();
	}
	public List<ContractEmployee> getContractEmployees()
	{
		return contractEmployeeRepo.findAll();
	}
	public List<Employee> getEmployees()
	{
		return employeeRepo.findAll();
	}
}
