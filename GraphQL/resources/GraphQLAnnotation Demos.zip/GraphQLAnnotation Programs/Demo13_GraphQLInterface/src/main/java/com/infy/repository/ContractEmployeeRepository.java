package com.infy.repository;

import org.springframework.stereotype.Repository;

import com.infy.entity.ContractEmployee;


@Repository
public interface ContractEmployeeRepository extends EmployeeBaseRepository<ContractEmployee>{
}

