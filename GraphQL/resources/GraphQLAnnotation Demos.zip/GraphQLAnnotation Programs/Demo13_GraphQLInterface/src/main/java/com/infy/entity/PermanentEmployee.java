package com.infy.entity;

import javax.persistence.Entity;

//package and import statements
@Entity
public class PermanentEmployee extends Employee
{
	
	private int  jobLevel ;
	
	public int getJobLevel() {
		return jobLevel;
	}
	public void setJobLevel(int jobLevel) {
		this.jobLevel = jobLevel;
	}
}
