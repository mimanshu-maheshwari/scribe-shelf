package com.infy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import com.infy.entity.Employee;

@NoRepositoryBean
//This annotation avoids creating repository proxies for the interfaces that match the 
//criteria of a repository interface but are not intended to be one. 
//Rather this will be extended by the actual repositories.
public interface EmployeeBaseRepository<T extends Employee> extends JpaRepository<T, String>{
}

