package com.infy.repository;

import org.springframework.stereotype.Repository;

import com.infy.entity.PermanentEmployee;

@Repository
public interface PermanentEmployeeRepository extends EmployeeBaseRepository<PermanentEmployee>{
}

