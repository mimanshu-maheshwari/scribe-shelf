package com.infy.entity;

import javax.persistence.Entity;

//package and import statements
@Entity
public class ContractEmployee extends Employee
{
		private String consultancyName;
		public String getConsultancyName() {
			return consultancyName;
		}
		public void setConsultancyName(String consultancyName) {
			this.consultancyName = consultancyName;
		}
}
