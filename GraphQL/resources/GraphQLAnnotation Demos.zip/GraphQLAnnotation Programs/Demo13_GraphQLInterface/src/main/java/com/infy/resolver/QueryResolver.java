package com.infy.resolver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import com.infy.entity.ContractEmployee;
import com.infy.entity.Employee;
import com.infy.entity.PermanentEmployee;
import com.infy.service.EmployeeService;


@Controller
public class QueryResolver {
	@Autowired
    private EmployeeService employeeService;
	
	@QueryMapping
	public List<PermanentEmployee> permanentEmployees()
	{
		return employeeService.getPermanentEmployees();
	}
	@QueryMapping
	public List<ContractEmployee> contractEmployees()
	{
		return employeeService.getContractEmployees();
	}
	@QueryMapping
	public List<Employee> employees()
	{
		return employeeService.getEmployees();
	}
}
