package com.infy.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.annotations.Parameter;
import org.hibernate.id.enhanced.SequenceStyleGenerator;


@Entity(name = "company")
public class Company {

	@Column(name = "cid", nullable = false)
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_seq2")
	@GenericGenerator(name = "my_seq2", strategy = "com.infy.entity.StringPrefixedSequenceIdGenerator", parameters = {
			@Parameter(name = SequenceStyleGenerator.INCREMENT_PARAM, value = "1"),
			@Parameter(name = SequenceStyleGenerator.INITIAL_PARAM, value = "234"),
			@Parameter(name = StringPrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "C") })
	private String cid;
	String name;
	String description;
	@LazyCollection(LazyCollectionOption.FALSE)
	@OneToMany(mappedBy = "company", cascade = CascadeType.ALL)
	List<Employee> employees;

	public String getCid() {
		return cid;
	}

	public String getDescription() {
		return description;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public String getName() {
		return name;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public void setName(String name) {
		this.name = name;
	}

}
