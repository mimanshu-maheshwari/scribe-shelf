package com.infy.resolvers.mutation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.service.EmployeeCompanyMutationService;


@Controller
public class TECMutation  {

	@Autowired
	private EmployeeCompanyMutationService tecService;

	@SchemaMapping(typeName="Mutation")
	public Company addCompany(@Argument("name") String name,@Argument("description") String description) {
		Company tec = new Company();
		tec.setName(name);
		tec.setDescription(description);
		return tecService.addCompany(tec);

	}
	@SchemaMapping(typeName="Mutation")
	public Employee addEmployee(@Argument("firstName") String firstName,@Argument("lastName") String lastName,@Argument("jobLevel") int jobLevel) {

		Employee emp = new Employee();
		emp.setFirstName(firstName);
		emp.setLastName(lastName);
		emp.setJobLevel(jobLevel);

		return tecService.addEmployee(emp);

	}
	@SchemaMapping(typeName="Mutation",field="mapCompEmp")
	public Employee getMapCompEmp(@Argument("compId")String compId,@Argument("empId") String empId) {
		return tecService.mapEmpComp(compId, empId);
	}
	@SchemaMapping(typeName="Mutation",field="unMapCompEmp")
	public Employee getUnMapCompEmp(@Argument("compId")String compId,@Argument("empId") String empId) {
		return tecService.unmapCompEmp(compId, empId);
	}

}
