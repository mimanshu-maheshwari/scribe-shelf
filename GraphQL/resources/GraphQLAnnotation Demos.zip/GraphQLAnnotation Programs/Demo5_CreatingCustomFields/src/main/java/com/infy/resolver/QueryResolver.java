package com.infy.resolver;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import com.infy.entity.Company;
import com.infy.entity.Employee;

import com.infy.service.Services;





@Controller
public class QueryResolver {

	@Autowired
	private Services service;
	
	private static final Log LOGGER = LogFactory.getLog(QueryResolver.class);
	
	@SchemaMapping(typeName="Query")
	public List<Employee> employees()
	{
		return service.getEmployees();
	}
	@SchemaMapping(typeName="Query",field = "companies")
	public List<Company> getCompanies()
	{
		return service.getAllCompanies();
	}
	
	@QueryMapping(name="employeeById")
	public Employee employeeById(@Argument("id") String id)
	{
		return service.getEmployeeById(id);
	}
	@QueryMapping
	public Company companyById(@Argument("id") String id)
	{
		return service.getCompanyById(id);
	}
	
	@SchemaMapping(typeName="Employee",field = "fullName")
	public String fullName(Employee emp)
	{
		LOGGER.info("From fullName Resolver");
		return service.fullName(emp);
	}
	@SchemaMapping(typeName="Employee")
	public Double totalSal(Employee emp)
	{
		return service.totalSal(emp);
	}
	
}
