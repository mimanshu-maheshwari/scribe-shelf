package com.infy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo5CreatingCustomFieldsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Demo5CreatingCustomFieldsApplication.class, args);
	}

}
