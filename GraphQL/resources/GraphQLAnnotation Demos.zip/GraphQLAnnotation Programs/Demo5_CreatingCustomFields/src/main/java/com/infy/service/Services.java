package com.infy.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.repo.CompanyRepository;
import com.infy.repo.EmployeeRepository;



@Service
public class Services {

	@Autowired
	private EmployeeRepository empRepo;
	@Autowired
	private CompanyRepository compRepo;
	
	public List<Employee> getEmployees()
	{
		return empRepo.findAll();
		
	}
	public List<Company> getAllCompanies()
	{
		return compRepo.findAll();
		
	}
	public Employee getEmployeeById(String id) {
		Optional<Employee> emp = empRepo.findById(id);
		if(emp.isPresent())
		{
			return emp.get();
		}
			
		
		return null;
	}
	
	public Company getCompanyById(String id) {
		Optional<Company> comp = compRepo.findById(id);
		if(comp.isPresent())
		{
			return comp.get();
		}
			
		
		return null;
	}
	
	public String fullName(Employee emp) {
		
		return emp.getFirstName()+" "+emp.getLastName();
			}
	public Double totalSal(Employee emp) {
		Double hra = emp.getSalary()*0.05;
		Double ta = emp.getSalary()*0.13; 
		Double da = emp.getSalary()*0.2; // Assume da is 20%, ta is 13% and hra is 5% of basic 
		return emp.getSalary()+hra+ta+da;
	}
	
}
