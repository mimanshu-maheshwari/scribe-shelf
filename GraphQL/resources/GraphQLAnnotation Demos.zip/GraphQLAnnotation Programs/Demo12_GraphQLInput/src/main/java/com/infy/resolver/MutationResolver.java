package com.infy.resolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.service.EmployeeCompanyMutationService;

@Controller
public class MutationResolver   {
	@Autowired
	private EmployeeCompanyMutationService tecService;
	
	
	// Add a new Company
	@SchemaMapping(typeName="Mutation",field="addCompany")
	public Company addCompany(@Argument("name") String name, @Argument("description") String description) {
		Company tec = new Company();
		tec.setName(name);
		tec.setDescription(description);
		return tecService.addCompany(tec);
	}
	// Add a new Company
	@SchemaMapping(typeName="Mutation")
	public Employee addEmployee(@Argument String firstName,@Argument String lastName, @Argument int jobLevel) {
		Employee emp = new Employee();
		emp.setFirstName(firstName);
		emp.setLastName(lastName);
		emp.setJobLevel(jobLevel);
		return tecService.addEmployee(emp);
	}
	// Map Employee to Company
	
	@SchemaMapping(typeName="Mutation",field="mapCompEmp")
	public  Employee mapCompEmp(@Argument("input") CompEmp compemp) {
		return tecService.mapEmpComp(compemp);
	}
	//UnMap Company from Employee
	@SchemaMapping(typeName="Mutation",field="unMapCompEmp")
	public Employee getUnMapCompEmp(@Argument("input") CompEmp compemp) {
		return tecService.unmapCompEmp(compemp);
	}
}
