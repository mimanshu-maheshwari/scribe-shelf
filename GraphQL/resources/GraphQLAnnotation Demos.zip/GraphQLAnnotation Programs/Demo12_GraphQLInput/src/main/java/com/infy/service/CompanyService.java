package com.infy.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.entity.Company;
import com.infy.repository.CompanyRepository;

import java.util.List;
import java.util.Optional;
 
@Service
public class CompanyService {
	@Autowired
    private CompanyRepository companyRepository ;
	
	public Company getCompanyById(String companyId)
	{
		Company company = null;
		
		Optional<Company> companyOptional = companyRepository.findById(companyId);
		if(companyOptional.isPresent())
			company = companyOptional.get();
		return company;
	}
	
	public List<Company> getAllCompanies( ) 
	{
        return this.companyRepository.findAll();
    }
	
}
