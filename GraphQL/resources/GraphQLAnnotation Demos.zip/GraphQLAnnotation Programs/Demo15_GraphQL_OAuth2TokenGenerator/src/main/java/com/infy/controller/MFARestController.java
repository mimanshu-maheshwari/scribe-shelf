package com.infy.controller;

import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@EnableOAuth2Sso //Resource marked with this annotation is responsible for authenticating the users //using an OAuth2 Authorization Server. Also, 
@RestController 
class MFARestController {

    @GetMapping("/")
    //endpoint that contacts the OAuth server to get the authentication details and returns the 
    //token
    public String home(java.security.Principal user) {
    	OAuth2AuthenticationDetails details = (OAuth2AuthenticationDetails) ((OAuth2Authentication)user).getDetails();
        return details.getTokenValue();
    }

}