# graphql-with-spring-boot
A sample application with GraphQL and Spring Boot

mutation{createVehicle(name:"car",modelCode:"toyota",brandName:"toy",launchDate:"2020-10-10") {
  id
}
}
