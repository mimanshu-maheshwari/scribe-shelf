package com.infy.exception;

@SuppressWarnings("serial")
public class TECException extends RuntimeException {
	public TECException(String str) {
		super(str);
	}
}


