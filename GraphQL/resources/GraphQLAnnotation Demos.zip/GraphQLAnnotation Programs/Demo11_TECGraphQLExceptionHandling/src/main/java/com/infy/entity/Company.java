package com.infy.entity;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
@Entity
public class Company {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "company_seq")
	@GenericGenerator(name = "company_seq", strategy = "com.infy.entity.CustomStringSequenceIdGenerator", parameters = {
			@Parameter(name = SequenceStyleGenerator.INCREMENT_PARAM, value = "50"),
			@Parameter(name = CustomStringSequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "C"),
			@Parameter(name = SequenceStyleGenerator.INITIAL_PARAM, value = "234"),
			@Parameter(name = CustomStringSequenceIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%d") })
	private String cid;
	private String name;
	private String description;
	@OneToMany(mappedBy = "company", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Employee> employees = new ArrayList<>();
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	public String getCid() {
		return cid;
	}
	public void setCId(String cid) {
		this.cid = cid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
