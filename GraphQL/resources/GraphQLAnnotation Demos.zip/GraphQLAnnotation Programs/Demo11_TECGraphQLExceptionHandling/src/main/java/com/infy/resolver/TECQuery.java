package com.infy.resolver;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;
import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.service.CompanyService;
import com.infy.service.EmployeeService;
@Controller
public class TECQuery  {
	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private CompanyService companyService;
	
	
	@SchemaMapping(typeName="Query")
	public List<Employee> employees() {
		return employeeService.getAllEmployees();
	}
	
	@SchemaMapping(typeName="Query",field="companies")
	public List<Company> getCompanies() {
		return companyService.getAllCompanies();
	}
	@SchemaMapping(typeName="Query")
	public Employee employeeById(@Argument("id") String employeeId) {
		return employeeService.getEmployeeById(employeeId);
	}
	@SchemaMapping(typeName="Query")
	public Company companyById(@Argument("cid") String companyId) {
		return companyService.getCompanyById(companyId);
	}
	
	
	@SchemaMapping(typeName="Employee",field="company")
	public Company getCompany(Employee employee) {
		return employee.getCompany();
	}
	
	@SchemaMapping(typeName="Company",field="employees")
	public List<Employee> employees(Company company) {
		return company.getEmployees();
	}
}
