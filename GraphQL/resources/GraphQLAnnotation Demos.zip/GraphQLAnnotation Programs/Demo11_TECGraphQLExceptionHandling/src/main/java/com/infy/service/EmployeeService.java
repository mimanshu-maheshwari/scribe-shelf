package com.infy.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.infy.entity.Employee;
import com.infy.exception.TECException;
import com.infy.repository.EmployeeRepository;
@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	public Employee getEmployeeById(String employeeId) {
		Employee employee = null;
		Optional<Employee> employeeOptional = employeeRepository.findById(employeeId);
		if (employeeOptional.isPresent())
			employee = employeeOptional.get();
		else
			throw new TECException("No such Employee with id:" + employeeId + " exists");
		return employee;
	}
	public List<Employee> getAllEmployees() {
		return this.employeeRepository.findAll();
	}
	public Employee createEmployee(Employee employee) {
		return employeeRepository.saveAndFlush(employee);
	}
}