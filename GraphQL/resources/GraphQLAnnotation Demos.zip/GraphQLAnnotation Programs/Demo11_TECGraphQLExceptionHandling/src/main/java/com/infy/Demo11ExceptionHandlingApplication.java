package com.infy;

import java.util.ArrayList;
import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import com.infy.exception.GQLErrorAdapter;
import graphql.ExceptionWhileDataFetching;
import graphql.GraphQLError;

import graphql.kickstart.execution.error.GraphQLErrorHandler;

@SpringBootApplication
public class Demo11ExceptionHandlingApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(Demo11ExceptionHandlingApplication.class, args);
	}
	
	 @Bean
		public GraphQLErrorHandler errorHandler() {
			return new GraphQLErrorHandler() {
				@Override
				public List<GraphQLError> processErrors(List<GraphQLError> errors) {
					List<GraphQLError> clientIssues = errors.stream()
							.filter(this::isClientError) 
							.toList();
					List<GQLErrorAdapter> serverIssues = errors.stream()
							.filter(e -> !isClientError(e)) 
							.map(GQLErrorAdapter::new)
							.toList();
					List<GraphQLError> e = new ArrayList<>();
					e.addAll(clientIssues);
					e.addAll(serverIssues);
					return e;
				}
				protected boolean isClientError(GraphQLError error) {
					return !(error instanceof ExceptionWhileDataFetching || error instanceof Throwable);
					                     
				}
			};
		}


}
