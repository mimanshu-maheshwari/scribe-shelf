package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.entity.Company;
import com.infy.entity.Employee;
import com.infy.repo.CompanyRepository;
import com.infy.repo.EmployeeRepository;


@Service
public class Services {

	@Autowired
	private EmployeeRepository empRepo;
	@Autowired
	private CompanyRepository compRepo;
	static final String MESSAGE = "Employee_Company GraphQL with Annotations";
	public List<Employee> getEmployees()
	{
		return empRepo.findAll();
	}
	public List<Company> getAllCompanies()
	{
		return compRepo.findAll();
	}
	public String getMessage()
	{
		return MESSAGE;
	}
}
