package com.infy.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee {
	@Id
	private String eId;
	private String firstName;
	private String lastName;
	private Integer jobLevel;
	public String getEid() {
		return eId;
	}
	public void setEid(String eId) {
		this.eId = eId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Integer getJobLevel() {
		return jobLevel;
	}
	public void setJobLevel(Integer jobLevel) {
		this.jobLevel = jobLevel;
	}
	@Override
	public String toString() {
		return "Employee [id=" + eId + ", firstName=" + firstName + ", lastName=" + lastName + ", jobLevel=" + jobLevel
				+ "]";
	}
	public Employee(String eId, String firstName, String lastName, Integer jobLevel) {
		super();
		this.eId = eId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.jobLevel = jobLevel;
	}
	public Employee() {
		super();
	}
	
	
	 
	 
}
