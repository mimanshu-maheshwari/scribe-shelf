package com.infy.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Company {
	@Id
	private String cId;
	private String cName;
	private String cType;
	public String getcId() {
		return cId;
	}
	public void setcId(String cId) {
		this.cId = cId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcType() {
		return cType;
	}
	public void setcType(String cType) {
		this.cType = cType;
	}
	@Override
	public String toString() {
		return "CompanyEntity [cId=" + cId + ", cName=" + cName + ", cType=" + cType + "]";
	}
	public Company(String cId, String cName, String cType) {
		super();
		this.cId = cId;
		this.cName = cName;
		this.cType = cType;
	}
	public Company() {
		super();
		}
	
	

}
